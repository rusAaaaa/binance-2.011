# Практика, которая сделает тебя FRONTEND разработчиком | React Crypto App

Видео тут: https://youtu.be/S4HOy6yTclU

Исходный код начала: https://t.me/js_by_vladilen/796
